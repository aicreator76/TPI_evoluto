﻿# TPI_evoluto - Guida rapida (PRE-INSTALLAZIONE)

1. Copia l'intera cartella "TPI_evoluto_portabile" in un percorso sicuro (es. C:\ o su USB).
2. Per avviare la dashboard offline:
   - Doppio clic su "START TPI.cmd"
   - Si aprirÃ  il browser con la dashboard TPI (non serve Python nÃ© Internet).
3. Requisiti:
   - Windows 10 o 11
   - Nessuna installazione richiesta
   - ModalitÃ  read-only
4. In caso di problemi, apri "index.html" direttamente con Edge/Chrome/Firefox.
