﻿# TPI_evoluto - Progetto ufficiale

Questa versione portabile contiene la dashboard base (HTML) in sola lettura.
Per la versione completa (FastAPI, logging, i18n IT/EN/FR/DE, ruoli: datore di lavoro, revisore, RSPP, lavoratore, supervisore) visita il repository:

- GitHub: https://github.com/aicreator76/TPI_evoluto

## Come contribuire
- git clone https://github.com/aicreator76/TPI_evoluto.git
- branch suggeriti: feature/logging-middleware, feature/i18n
- apri PR verso main

## Contenuto pacchetto portabile
- index.html
- START TPI.cmd / start.cmd
- README_PRE.txt
- README_PROGETTO.txt
