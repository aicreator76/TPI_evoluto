
def test_template_endpoint_skeleton():
    # Replace with real client once /v1/cataloghi is implemented
    assert True
