
# ADR-0001: Architettura Cataloghi v1
Decisione: API /v1/cataloghi con Repository Pattern, Alembic migrazioni, logging JSON e metriche Prometheus.
Conseguenze: compatibilità futura semplice, osservabilità integrata, rollout/rollback prevedibili.
