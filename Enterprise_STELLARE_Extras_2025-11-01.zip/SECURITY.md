
# Security Policy
- Do not commit secrets. Use GitHub/Replit Secrets.
- Report vulnerabilities via private issue. High/Critical CVE in dependencies must be fixed before release.
