
param(
  [string]$RepoOwner = "aicreator76",
  [string]$RepoName = "TPI_evoluto",
  [string]$Branch = "main"
)
# Requires gh CLI authenticated
$checks = @(
  "Ruff",
  "PyTest",
  "Bandit",
  "pip-audit",
  "Trivy FS scan"
)
$payload = @{
  required_status_checks = @{
    strict = $true
    contexts = $checks
  }
  enforce_admins = $true
  required_pull_request_reviews = @{
    required_approving_review_count = 1
  }
  restrictions = $null
} | ConvertTo-Json -Depth 5
gh api -X PUT repos/$RepoOwner/$RepoName/branches/$Branch/protection -H "Accept: application/vnd.github+json" -f data="$payload"
