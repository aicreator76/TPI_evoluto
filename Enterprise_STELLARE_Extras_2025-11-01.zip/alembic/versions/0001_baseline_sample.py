
# Sample empty migration
revision = '0001_baseline'
down_revision = None
branch_labels = None
depends_on = None
def upgrade():
    pass
def downgrade():
    pass
