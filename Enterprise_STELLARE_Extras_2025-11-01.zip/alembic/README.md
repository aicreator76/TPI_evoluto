
# Alembic baseline (skeleton)
Run in repo root after integrating:
    alembic init alembic
    # replace env.py with configured DB target if needed
