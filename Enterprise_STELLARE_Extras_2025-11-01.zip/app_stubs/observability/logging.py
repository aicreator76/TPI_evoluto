
from __future__ import annotations
import logging
import json
import time
from typing import Any, Dict

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:  # type: ignore[override]
        base = {
            "ts": int(time.time() * 1000),
            "level": record.levelname,
            "name": record.name,
            "msg": record.getMessage(),
        }
        # Attach correlation id if present on the record
        cid = getattr(record, "correlation_id", None)
        if cid:
            base["correlationId"] = cid
        # Extra context dict if used via logger.bind(extra=...)
        if record.args and isinstance(record.args, dict):
            base.update(record.args)  # type: ignore[arg-type]
        return json.dumps(base, ensure_ascii=False)

def setup_json_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
