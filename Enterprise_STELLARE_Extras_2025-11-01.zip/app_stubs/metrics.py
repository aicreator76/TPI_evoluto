
from __future__ import annotations
from starlette_exporter import PrometheusMiddleware, handle_metrics  # type: ignore

def mount_metrics(app, route: str = "/metrics"):
    # Adds request metrics + exposes /metrics endpoint
    app.add_middleware(PrometheusMiddleware)
    app.add_route(route, handle_metrics)
