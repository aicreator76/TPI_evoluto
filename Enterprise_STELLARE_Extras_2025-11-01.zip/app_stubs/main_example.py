
# Example FastAPI app showing health, logging and metrics mounting.
from __future__ import annotations
from fastapi import FastAPI, Request
from .observability.logging import setup_json_logging
from .metrics import mount_metrics

setup_json_logging()

app = FastAPI()

@app.get("/health")
def health():
    return {"ok": True}

mount_metrics(app)
