﻿# Chat Package - 2025-09-14
Cosa contiene:
- Spezzoni dei file testuali troppo grandi (chunks)
- Conversioni: DOCXâ†’TXT, XLSXâ†’CSV (1 per foglio), PPTXâ†’TXT, PDFâ†’TXT (se 'pdftotext')
- OCR immagini â†’ TXT 
- Manifest JSON con hash
- README + prompt base

Note:
- Se un file testuale supera 512KB viene suddiviso in chunk da ~120KB.
- Flag: -Recreate 

## Contenuti:
- TEXT: requirements.txt
- TEXT: vendor.txt
- TEXT: entry_points.txt
- TEXT: top_level.txt
- TEXT: AUTHORS.txt
- TEXT: LICENSE.txt
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: LICENSE.md
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: LICENSE.md (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: LICENSE.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: top_level.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
- TEXT: LICENSE.md (giÃ  presente)
- TEXT: LICENSE.md (giÃ  presente)
- TEXT: entry_points.txt (giÃ  presente)
