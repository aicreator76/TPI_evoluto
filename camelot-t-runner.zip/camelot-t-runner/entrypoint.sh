#!/usr/bin/env sh
set -e

# This entrypoint simply starts the Uvicorn server pointing at the FastAPI app.
exec uvicorn app.main:app --host 0.0.0.0 --port 8080