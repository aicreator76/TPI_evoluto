"""
Pydantic models for the T Runner service.

Defines the structure of the incoming request and the allowed commands for the service.
"""

from __future__ import annotations

from pydantic import BaseModel, Field, ValidationError, validator
from typing import List, Literal, Optional, Dict, Any


class Step(BaseModel):
    """Represents a single command to execute within an order.

    Allowed commands are defined via Literal to enforce strict typing.
    Optional fields are provided for each command; unused fields are ignored.
    """

    cmd: Literal["echo", "http_post", "sleep", "write_log"]
    text: Optional[str] = None
    seconds: Optional[float] = Field(
        default=None, ge=0.0, description="Duration in seconds for sleep; must be non‑negative."
    )
    url: Optional[str] = Field(
        default=None, description="Target URL for http_post commands."
    )
    body: Optional[Dict[str, Any]] = Field(
        default=None, description="JSON body for http_post commands."
    )
    data: Optional[Dict[str, Any]] = Field(
        default=None, description="Data to log for write_log commands."
    )
    headers: Optional[Dict[str, str]] = Field(
        default=None, description="Extra headers for http_post commands."
    )

    @validator("seconds")
    def validate_seconds(cls, v: Optional[float]) -> Optional[float]:
        """Ensure that the seconds parameter is within an acceptable range.

        Sleep durations longer than five seconds are disallowed to prevent abuse.
        """
        if v is not None and v > 5.0:
            raise ValueError("sleep seconds must be ≤ 5")
        return v


class Order(BaseModel):
    """Represents a full order to be processed by the service.
    
    Contains an intent identifier and a list of steps to execute.
    """

    intent: str = Field(
        default="t_execute",
        description="Logical intent for the order; defaults to t_execute."
    )
    steps: List[Step] = Field(
        ..., description="Ordered list of steps that make up the order."
    )


class ExecuteRequest(BaseModel):
    """Top‑level request body model for the ``/t/execute`` endpoint."""

    order: Order
    dry_run: bool = Field(
        default=False, description="Whether to perform a dry‑run; only echo commands are executed."
    )
