"""
In‑memory idempotency cache.

Stores responses keyed by idempotency keys for a limited time. When the same
key is encountered again within the TTL, the stored response is returned
instead of executing the request again.
"""

import asyncio
import time
from typing import Any, Dict, Optional, Tuple


class IdempotencyCache:
    """Caches responses for idempotent requests for a fixed TTL.

    Because the service is stateless apart from this cache, the cache is kept
    entirely in memory. Expired entries are cleaned up lazily on access to
    minimise overhead.
    """

    def __init__(self, ttl_seconds: float = 600.0) -> None:
        self.ttl_seconds = ttl_seconds
        self._store: Dict[str, Tuple[float, Any]] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[Any]:
        """Return the cached response for the given key if it exists and is fresh."""
        now = time.monotonic()
        async with self._lock:
            item = self._store.get(key)
            if item is None:
                return None
            timestamp, response = item
            if (now - timestamp) > self.ttl_seconds:
                # Expired; remove entry
                del self._store[key]
                return None
            return response

    async def set(self, key: str, value: Any) -> None:
        """Store the value for the given key with the current timestamp."""
        now = time.monotonic()
        async with self._lock:
            self._store[key] = (now, value)
