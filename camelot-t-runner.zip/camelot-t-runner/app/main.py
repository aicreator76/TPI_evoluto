"""
Main application module for the T Runner service.

This FastAPI application exposes several endpoints, including the primary
/t/execute endpoint for executing authorised orders. The service implements
authentication, optional HMAC signature verification, per‑IP rate limiting,
idempotency support, structured logging, and Prometheus metrics.

Environment variables used:

* ``T_TOKEN``         – shared secret token required in the ``X-Auth-Token`` header.
* ``T_HMAC_KEY``      – optional key for HMAC verification against ``X-Signature``.
* ``T_CORS``          – if set to ``1``, enable permissive CORS middleware.
* ``T_RATE_LIMIT``    – optional override for requests per minute (default 30).
* ``T_RATE_WINDOW``   – optional override for rate limit window in seconds (default 60).
"""

from __future__ import annotations

import asyncio
import json
import os
import logging
import os
from datetime import datetime
from typing import Any, Dict, Optional

import httpx
from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

from .models import ExecuteRequest, Step
from .rate_limiter import RateLimiter
from .idempotency_cache import IdempotencyCache
from .utils import (
    compute_hmac_signature,
    constant_time_compare,
    generate_trace_id,
    get_client_ip,
    get_env,
)


def setup_logging() -> None:
    """Configure the global logger to output JSON structured logs."""
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        fmt='{"time":"%(asctime)s","level":"%(levelname)s","trace_id":"%(trace_id)s","message":%(message)s}',
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    if not root.handlers:
        root.addHandler(handler)


# Initialise logging on import
setup_logging()
logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(title="T Runner Service", version="1.0.0", docs_url=None, redoc_url=None)

    # Read configuration from environment
    token: Optional[str] = get_env("T_TOKEN")
    hmac_key: Optional[str] = get_env("T_HMAC_KEY")
    enable_cors: bool = get_env("T_CORS") == "1"
    # Rate limit defaults: 30 requests per minute
    max_requests = int(get_env("T_RATE_LIMIT", "30"))
    window_seconds = float(get_env("T_RATE_WINDOW", "60"))

    rate_limiter = RateLimiter(max_requests, window_seconds)
    cache = IdempotencyCache(ttl_seconds=600.0)

    # Prometheus metrics
    # Register metrics only once per process. If they already exist in the
    # default Prometheus registry, reuse them to avoid duplication errors.
    from prometheus_client import REGISTRY
    collector_names = getattr(REGISTRY, "_names_to_collectors", {})
    if "t_runner_requests_total" in collector_names:
        request_counter = collector_names["t_runner_requests_total"]  # type: ignore
    else:
        request_counter = Counter(
            "t_runner_requests_total",
            "Total number of requests to t/execute",
            ["status"]
        )
    if "t_runner_request_duration_seconds" in collector_names:
        request_latency = collector_names["t_runner_request_duration_seconds"]  # type: ignore
    else:
        request_latency = Histogram(
            "t_runner_request_duration_seconds",
            "Request processing latency for t/execute",
            buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10)
        )

    # Apply CORS middleware if enabled
    if enable_cors:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    @app.middleware("http")
    async def add_trace_and_logging(request: Request, call_next):  # type: ignore[override]
        """Middleware to attach a trace_id and handle structured logging."""
        trace_id = request.headers.get("x-trace-id") or generate_trace_id()
        # Attach trace_id to logger context via custom filter
        extra = {"trace_id": trace_id}
        start_time = datetime.utcnow().timestamp()
        try:
            response = await call_next(request)
        except Exception as exc:
            # Unhandled exception, log and wrap into JSON error
            logger.error(json.dumps({"error": str(exc)}), extra=extra)
            request_counter.labels(status="500").inc()
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "ok": False,
                    "error": "Internal server error",
                    "code": 500,
                    "trace_id": trace_id,
                },
            )
        duration = datetime.utcnow().timestamp() - start_time
        request_latency.observe(duration)
        # Ensure trace_id is included in response headers
        response.headers["X-Trace-Id"] = trace_id
        return response

    @app.get("/healthz", include_in_schema=False)
    async def healthz() -> Response:
        """Readiness probe."""
        return PlainTextResponse("ok")

    @app.get("/livez", include_in_schema=False)
    async def livez() -> Response:
        """Liveness probe."""
        return PlainTextResponse("alive")

    @app.get("/metrics", include_in_schema=False)
    async def metrics() -> Response:
        """Expose Prometheus metrics."""
        data = generate_latest()
        return Response(content=data, media_type=CONTENT_TYPE_LATEST)

    async def authenticate(request: Request, body: bytes, trace_id: str) -> None:
        """Authenticate the incoming request using token and optional HMAC."""
        if not token:
            # No token configured, deny all requests
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication not configured")
        provided_token = request.headers.get("x-auth-token")
        if not provided_token or provided_token != token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing auth token")
        if hmac_key:
            signature = request.headers.get("x-signature")
            if not signature:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing signature")
            expected = compute_hmac_signature(body, hmac_key)
            if not constant_time_compare(signature, expected):
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid signature")

    async def process_step(step: Step, dry_run: bool, trace_id: str) -> Dict[str, Any]:
        """Execute a single step and return a result dictionary.

        Handles dry run semantics, command dispatching, error handling and
        retry logic for http_post operations.
        """
        cmd = step.cmd
        if dry_run and cmd != "echo":
            return {"i": None, "cmd": cmd, "ok": True, "dry_run": True}
        # Dispatch commands
        if cmd == "echo":
            return {"i": None, "cmd": cmd, "ok": True, "result": {"echo": step.text or ""}}
        if cmd == "sleep":
            seconds = step.seconds or 0.0
            # Sleep asynchronously to avoid blocking the event loop
            await asyncio.sleep(seconds)
            return {"i": None, "cmd": cmd, "ok": True, "result": {"slept": seconds}}
        if cmd == "write_log":
            data = step.data or {}
            # Write log on a background thread
            def _write():
                date_str = datetime.utcnow().strftime("%Y-%m-%d")
                log_dir = "/var/log/t_runner"
                os.makedirs(log_dir, exist_ok=True)
                file_path = os.path.join(log_dir, f"{date_str}.log")
                with open(file_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(data, ensure_ascii=False) + "\n")
                return file_path
            path = await asyncio.to_thread(_write)
            return {"i": None, "cmd": cmd, "ok": True, "result": {"file": path}}
        if cmd == "http_post":
            url = step.url
            if not url:
                return {"i": None, "cmd": cmd, "ok": False, "error": "Missing URL"}
            headers = step.headers or {}
            payload = step.body or {}
            # Implement retry logic
            for attempt, backoff in enumerate([0.0, 0.2, 0.5]):
                try:
                    async with httpx.AsyncClient(timeout=10.0) as client:
                        resp = await client.post(url, json=payload, headers=headers)
                        text = resp.text[:4096]
                        return {
                            "i": None,
                            "cmd": cmd,
                            "ok": True,
                            "result": {"code": resp.status_code, "out": text},
                        }
                except Exception as exc:
                    error_msg = str(exc)
                    if attempt < 2:
                        await asyncio.sleep(backoff)
                        continue
                    return {
                        "i": None,
                        "cmd": cmd,
                        "ok": False,
                        "error": error_msg,
                    }
        # Should never reach here
        return {"i": None, "cmd": cmd, "ok": False, "error": "Unknown command"}

    @app.post("/t/execute")
    async def t_execute(request: Request) -> Response:
        """Handle execution requests for orders."""
        trace_id = request.headers.get("x-trace-id") or generate_trace_id()
        extra = {"trace_id": trace_id}
        # Read raw body for signature verification
        body = await request.body()
        # Authenticate
        try:
            await authenticate(request, body, trace_id)
        except HTTPException as exc:
            logger.warning(json.dumps({"error": exc.detail}), extra=extra)
            request_counter.labels(status=str(exc.status_code)).inc()
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "ok": False,
                    "error": exc.detail,
                    "code": exc.status_code,
                    "trace_id": trace_id,
                },
            )
        # Rate limit
        client_ip = get_client_ip(request)
        allowed = await rate_limiter.allow(client_ip)
        if not allowed:
            logger.warning(json.dumps({"error": "Rate limit exceeded", "ip": client_ip}), extra=extra)
            request_counter.labels(status="429").inc()
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "ok": False,
                    "error": "Too many requests",
                    "code": 429,
                    "trace_id": trace_id,
                },
            )
        # Idempotency
        idem_key = request.headers.get("x-idempotency-key")
        if idem_key:
            cached = await cache.get(idem_key)
            if cached is not None:
                logger.info(json.dumps({"cached": True}), extra=extra)
                # Return cached response
                request_counter.labels(status="200").inc()
                resp = JSONResponse(content=cached)
                resp.headers["X-Trace-Id"] = trace_id
                resp.headers["X-Idempotency-Cache"] = "hit"
                return resp
        # Parse JSON body
        try:
            payload = json.loads(body.decode("utf-8"))
            req_model = ExecuteRequest.model_validate(payload)
        except Exception as exc:
            logger.warning(json.dumps({"error": "Invalid request body"}), extra=extra)
            request_counter.labels(status="400").inc()
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={
                    "ok": False,
                    "error": "Invalid request body",
                    "code": 400,
                    "trace_id": trace_id,
                },
            )
        results = []
        overall_ok = True
        # Execute steps sequentially
        for idx, step in enumerate(req_model.order.steps, 1):
            res = await process_step(step, req_model.dry_run, trace_id)
            res["i"] = idx
            results.append(res)
            if not res.get("ok", True):
                overall_ok = False
        response_body: Dict[str, Any] = {
            "ok": overall_ok,
            "dry_run": req_model.dry_run,
            "results": results,
            "trace_id": trace_id,
        }
        # Store in idempotency cache
        if idem_key:
            await cache.set(idem_key, response_body)
        logger.info(json.dumps({"ok": overall_ok, "results": len(results)}), extra=extra)
        request_counter.labels(status="200").inc()
        resp = JSONResponse(content=response_body)
        resp.headers["X-Trace-Id"] = trace_id
        return resp

    return app


app = create_app()
