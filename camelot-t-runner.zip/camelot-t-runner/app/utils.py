"""
Utility functions and helpers for the T Runner service.

Provides functionality for generating trace identifiers, reading environment
configuration, computing and verifying HMAC signatures, and extracting client
IP addresses from requests. Secrets are never logged or exposed.
"""

import hashlib
import hmac
import os
import time
import uuid
from typing import Optional

from fastapi import Request


def get_client_ip(request: Request) -> str:
    """Attempt to determine the client's IP address.

    Uses X‑Forwarded‑For if present, otherwise falls back to the remote address.
    """
    xff = request.headers.get("x-forwarded-for")
    if xff:
        # The first IP in the list is the original client
        return xff.split(",", 1)[0].strip()
    return request.client.host or "unknown"


def generate_trace_id() -> str:
    """Generate a new trace identifier.

    Uses UUID4 hex representation for randomness and uniqueness.
    """
    return uuid.uuid4().hex


def get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    """Fetch an environment variable in a case‑insensitive manner."""
    # Attempt exact key
    val = os.environ.get(key)
    if val is not None:
        return val
    # Fallback to upper/lower variants
    val = os.environ.get(key.upper())
    if val is not None:
        return val
    return default


def compute_hmac_signature(body: bytes, key: str) -> str:
    """Compute a hex HMAC‑SHA256 of the body using the provided key."""
    h = hmac.new(key.encode("utf-8"), body, hashlib.sha256)
    return h.hexdigest()


def constant_time_compare(val1: str, val2: str) -> bool:
    """Perform a constant‑time comparison between two strings."""
    # Ensure both are the same length to avoid timing differences
    return hmac.compare_digest(val1.encode("utf-8"), val2.encode("utf-8"))
