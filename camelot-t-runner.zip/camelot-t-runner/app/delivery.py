"""
SMB delivery module for copying artefacts to Windows shares.

This module mounts SMB shares for the C: and E: drives of a Windows host
using credentials provided via environment variables, then copies a source
artefact into the appropriate Camelot directory on each drive. It verifies
that the copied files have matching SHA256 digests, performs a simple smoke
test, and writes a report.

The module is designed to be invoked from within the T Runner service or as
a standalone script. All operations are idempotent and robust: on failures
it will retry once before giving up and signalling a blocking condition.

Environment variables required:

* ``WIN_SMB_HOST``      – hostname or IP of the Windows machine hosting the shares.
* ``WIN_SMB_SHARE_C``   – share name for C: (e.g. ``C$``).
* ``WIN_SMB_SHARE_E``   – share name for E: (e.g. ``E$``).
* ``WIN_SMB_USER``      – username for SMB authentication.
* ``WIN_SMB_PASS``      – password for SMB authentication.
* ``PRODUCT``           – product name for the Camelot directory hierarchy.
* ``VERSION``           – version identifier.
* ``ARTIFACT_SRC``      – path to the artefact on the local filesystem.

Logging is written to ``/var/log/t_runner/delivery.log`` in JSON format.

Note: This code assumes that CIFS utilities are installed in the container
environment. If they are not available, the mount commands will fail.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Dict, Optional, Tuple


def _log(event: Dict[str, any]) -> None:
    """Append an event to the delivery log as a single JSON line."""
    log_dir = Path("/var/log/t_runner")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "delivery.log"
    event["time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _mount_share(host: str, share: str, mount_point: Path, creds_path: Path) -> bool:
    """Mount an SMB share to the specified mount point using credentials file."""
    # Create mount point
    mount_point.mkdir(parents=True, exist_ok=True)
    # Build mount command
    cmd = [
        "mount", "-t", "cifs", f"//{host}/{share}", str(mount_point),
        f"credentials={creds_path}", "vers=3.0", "iocharset=utf8",
        "file_mode=0644", "dir_mode=0755"
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except subprocess.CalledProcessError as exc:
        _log({"event": "mount_fail", "share": share, "error": exc.stderr.decode(errors="ignore")})
        return False


def _unmount_share(mount_point: Path) -> None:
    """Unmount the mounted SMB share."""
    try:
        subprocess.run(["umount", str(mount_point)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError:
        pass


def _sha256(path: Path) -> str:
    """Compute the SHA256 digest of a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _smoke_test(path: Path) -> bool:
    """Perform a basic smoke test on the artefact.

    For zip files, test archive integrity. For executables, ensure the file
    exists and is non‑empty. Additional checks can be added as needed.
    """
    name = path.name.lower()
    if name.endswith(".zip"):
        # Use unzip -tqq to test integrity quietly
        try:
            subprocess.run(["unzip", "-tqq", str(path)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return True
        except subprocess.CalledProcessError as exc:
            _log({"event": "smoke_fail", "error": exc.stderr.decode(errors="ignore")})
            return False
    # For executables or unknown types, just check size > 0
    return path.exists() and path.stat().st_size > 0


def deliver() -> Tuple[bool, Dict[str, str]]:
    """Perform the SMB delivery and return a tuple of (success, result dict)."""
    # Gather environment configuration
    required = [
        "WIN_SMB_HOST", "WIN_SMB_SHARE_C", "WIN_SMB_SHARE_E",
        "WIN_SMB_USER", "WIN_SMB_PASS", "PRODUCT", "VERSION", "ARTIFACT_SRC",
    ]
    env = {k: os.environ.get(k) for k in required}
    missing = [k for k, v in env.items() if not v]
    if missing:
        # Missing critical configuration
        note = f"Missing environment variables: {', '.join(missing)}"
        _log({"event": "config_missing", "missing": missing})
        return False, {"error": note, "prossima": "Fornire SMB credentials"}
    host = env["WIN_SMB_HOST"]
    share_c = env["WIN_SMB_SHARE_C"]
    share_e = env["WIN_SMB_SHARE_E"]
    user = env["WIN_SMB_USER"]
    passwd = env["WIN_SMB_PASS"]
    product = env["PRODUCT"]
    version = env["VERSION"]
    src = Path(env["ARTIFACT_SRC"]).resolve()
    # Prepare credentials file
    creds_path = Path("/run/creds")
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    creds_path.write_text(f"username={user}\npassword={passwd}\n", encoding="utf-8")
    # Mount shares
    c_mount = Path("/mnt/winC")
    e_mount = Path("/mnt/winE")
    mounted_c = _mount_share(host, share_c, c_mount, creds_path)
    mounted_e = _mount_share(host, share_e, e_mount, creds_path)
    # Retry once if mount fails
    if not mounted_c:
        time.sleep(1)
        mounted_c = _mount_share(host, share_c, c_mount, creds_path)
    if not mounted_e:
        time.sleep(1)
        mounted_e = _mount_share(host, share_e, e_mount, creds_path)
    if not mounted_c or not mounted_e:
        _log({"event": "mount_block", "c": mounted_c, "e": mounted_e})
        return False, {"error": "SMB mount failed", "prossima": "Verificare credenziali/host"}
    try:
        # Create destination directories
        c_dest_dir = c_mount / "Camelot" / product / version
        e_dest_dir = e_mount / "Camelot" / "backup" / product / version
        c_dest_dir.mkdir(parents=True, exist_ok=True)
        e_dest_dir.mkdir(parents=True, exist_ok=True)
        # Copy artefact
        artifact_name = src.name
        c_dest = c_dest_dir / artifact_name
        shutil.copy2(src, c_dest)
        # Duplicate to E
        e_dest = e_dest_dir / artifact_name
        shutil.copy2(c_dest, e_dest)
        # Compute hashes
        h_c = _sha256(c_dest)
        h_e = _sha256(e_dest)
        # Smoke test
        smoke_ok = _smoke_test(c_dest)
        # Generate report
        report_content = f"""\

STATO: {'OK' if (h_c == h_e and smoke_ok) else 'BLOCCO'}
PRODOTTO: {product} VERSIONE: {version}
C:\\ : {c_dest.as_posix().replace('/mnt/winC', 'C:')}
E:\\ : {e_dest.as_posix().replace('/mnt/winE', 'E:')}
SHA256 C:\\ : {h_c}
SHA256 E:\\ : {h_e} (deve coincidere con C:)
SMOKE TEST: {'OK' if smoke_ok else 'FAIL'} → test di integrità
ARTEFATTI: REPORT.md
PROSSIMA AZIONE: none
"""
        report_path_c = c_dest_dir / "REPORT.md"
        report_path_c.write_text(report_content, encoding="utf-8")
        shutil.copy2(report_path_c, e_dest_dir / "REPORT.md")
        # Log delivery
        _log({
            "event": "delivery", "product": product, "version": version,
            "c_dest": str(c_dest), "e_dest": str(e_dest), "sha256_c": h_c,
            "sha256_e": h_e, "smoke": smoke_ok
        })
        return True, {
            "c_path": c_dest.as_posix().replace("/mnt/winC", "C:"),
            "e_path": e_dest.as_posix().replace("/mnt/winE", "E:"),
            "sha256_c": h_c,
            "sha256_e": h_e,
            "smoke": "OK" if smoke_ok else "FAIL",
            "report": report_path_c.as_posix().replace("/mnt/winC", "C:")
        }
    finally:
        # Always unmount
        _unmount_share(c_mount)
        _unmount_share(e_mount)