"""
In‑memory sliding‑window rate limiter.

Implements per‑client IP rate limiting for the T Runner service. Each client is
allowed up to a fixed number of requests within a given time window. Requests
exceeding this limit are rejected until earlier entries expire.
"""

import asyncio
import time
from collections import defaultdict, deque
from typing import Deque, Dict


class RateLimiter:
    """Simple sliding‑window rate limiter.

    Tracks timestamps of requests per key (typically the client IP) and
    determines whether a new request is permitted. Uses an asynchronous lock
    to protect shared state.
    """

    def __init__(self, max_requests: int, window_seconds: float) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._timestamps: Dict[str, Deque[float]] = defaultdict(deque)
        self._lock = asyncio.Lock()

    async def allow(self, key: str) -> bool:
        """Determine if a request from `key` is within rate limits.

        Removes timestamps older than the sliding window and checks if the
        remaining number of requests exceeds the configured maximum.
        """
        now = time.monotonic()
        async with self._lock:
            q = self._timestamps[key]
            # Remove expired timestamps from left side of deque
            while q and (now - q[0]) > self.window_seconds:
                q.popleft()
            if len(q) >= self.max_requests:
                return False
            q.append(now)
        return True
