# T Runner Service

This repository contains a robust and production‑ready implementation of the **T Runner** service.  
It provides an HTTP API that executes whitelisted commands (`echo`, `http_post`, `sleep`, `write_log`) inside an order, with optional dry‑run support.  
The service implements authentication, rate limiting, idempotency, structured logging, health and metrics endpoints, and ships with a containerised deployment.

## Features

* **FastAPI + Uvicorn** asynchronous stack (Python 3.11).
* **Pydantic models** enforce strict typing of the request payload.
* **Authentication** via `X‑Auth‑Token` header (mandatory). Optional HMAC validation via `X‑Signature` if a `T_HMAC_KEY` is provided.
* **Rate limiting**: 30 requests per minute per client IP (configurable).
* **Idempotency**: subsequent requests with the same `X‑Idempotency‑Key` return the cached response for 10 minutes.
* **Retry/backoff** on `http_post` commands (10 s timeout, 2 retries).
* **Structured JSON logging** with a generated `trace_id` on each request. Logs are emitted at INFO/ERROR levels without exposing secrets.
* **Observability**: `/healthz` (readiness), `/livez` (liveness) and `/metrics` (Prometheus) endpoints.
* **Docker and Compose**: ready for deployment with a non‑root user and configurable environment variables.
* **Test suite**: unit and end‑to‑end tests using `pytest` and `httpx`.

## Quickstart

### Development

1. Create and activate a virtual environment (optional but recommended):

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```

2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Set required environment variables (for example via a `.env` file or exporting directly). At minimum you must set `T_TOKEN`.

4. Run the service in development mode:

   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8080
   ```

5. Send a test request:

   ```bash
   curl -s -X POST http://localhost:8080/t/execute \
        -H 'Content-Type: application/json' \
        -H 'X-Auth-Token: your_token' \
        -d '{"order":{"steps":[{"cmd":"echo","text":"ping"}]}, "dry_run": false}' | jq
   ```

### Running Tests

The test suite requires `pytest` and `pytest‑asyncio`. To run all tests:

```bash
pytest
```

Tests exercise the primary happy‑path, idempotency, authentication failure, and rate limiting behaviour.

### Docker

To build and run the service using Docker:

```bash
docker build -t trunner:latest .
docker run --rm -p 8080:8080 -e T_TOKEN=your_token trunner:latest
```

Alternatively, use Docker Compose for a declarative setup:

```bash
cp .env.example .env  # edit values accordingly
docker compose up -d
```

The service will be available on port 8080. Compose binds `./logs` on the host to `/var/log/t_runner` in the container for persistent log storage.

## API

### POST `/t/execute`

Execute an order consisting of one or more steps. Each step must specify a `cmd` and appropriate fields. See the Pydantic models in `app/models.py` for details.

Request body example:

```json
{
  "order": {
    "intent": "t_execute",
    "steps": [
      { "cmd": "echo", "text": "ping" },
      { "cmd": "sleep", "seconds": 0.2 },
      { "cmd": "write_log", "data": { "note": "boot" } }
    ]
  },
  "dry_run": false
}
```

Required headers:

* `X-Auth-Token`: your shared secret token.

Optional headers:

* `X-Idempotency-Key`: idempotency key to cache results for 10 minutes.
* `X-Signature`: HMAC-SHA256 of the raw body using your secret `T_HMAC_KEY`.

On success the service returns a JSON response with `ok: true`, a results array, and the generated `trace_id`. On failure the response includes `ok: false`, an error message, HTTP code, and trace identifier.

## Delivery Module

The repository includes a delivery module for copying artefacts from a Linux environment onto Windows SMB shares (C: and E: drives). See the module source for details. Delivery requires the following environment variables:

* `WIN_SMB_HOST`, `WIN_SMB_SHARE_C`, `WIN_SMB_SHARE_E`, `WIN_SMB_USER`, `WIN_SMB_PASS` – SMB connection details.
* `PRODUCT`, `VERSION`, `ARTIFACT_SRC` – metadata and source file path.

The module mounts the SMB shares under `/mnt/winC` and `/mnt/winE`, copies the artefact, verifies SHA256 sums and performs a smoke test, then writes a report. Logs are written to `/var/log/t_runner/delivery.log`.

## Notes

* Do not commit real tokens or credentials. Use environment variables or an external secret manager to inject secrets at runtime.
* The built image is based on `python:3.11-slim` and is under 200 MB.
* The service runs as a non‑root user inside the container.
* Timezone is configurable via `TZ` (default `Europe/Amsterdam`).