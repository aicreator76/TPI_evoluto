"""
Unit and end‑to‑end tests for the T Runner service.

The tests use httpx's AsyncClient to exercise the FastAPI application without
starting an external server. Environment variables are patched as needed
via monkeypatch to configure authentication and rate limiting for the tests.
"""

import asyncio
import os
import pytest
import httpx
from app.main import create_app


@pytest.fixture
def settings(monkeypatch):
    """Patch environment variables for each test."""
    monkeypatch.setenv("T_TOKEN", "secret")
    # Clear optional values
    monkeypatch.delenv("T_HMAC_KEY", raising=False)
    monkeypatch.delenv("T_CORS", raising=False)
    monkeypatch.delenv("T_RATE_LIMIT", raising=False)
    monkeypatch.delenv("T_RATE_WINDOW", raising=False)
    yield
    # Clean up happens automatically


@pytest.mark.asyncio
async def test_execute_echo(settings):
    app = create_app()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        resp = await client.post(
            "/t/execute",
            json={"order": {"steps": [{"cmd": "echo", "text": "ping"}]}, "dry_run": False},
            headers={"X-Auth-Token": "secret"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["results"]) == 1
        assert data["results"][0]["result"]["echo"] == "ping"


@pytest.mark.asyncio
async def test_auth_missing(settings):
    app = create_app()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        resp = await client.post(
            "/t/execute",
            json={"order": {"steps": [{"cmd": "echo", "text": "ping"}]}, "dry_run": False},
        )
        assert resp.status_code == 401
        data = resp.json()
        assert data["ok"] is False
        assert "auth" in data["error"].lower()


@pytest.mark.asyncio
async def test_idempotency(settings):
    app = create_app()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        headers = {"X-Auth-Token": "secret", "X-Idempotency-Key": "abc123"}
        body = {"order": {"steps": [{"cmd": "echo", "text": "pong"}]}, "dry_run": False}
        # First request
        first = await client.post("/t/execute", json=body, headers=headers)
        assert first.status_code == 200
        # Second request should return cached
        second = await client.post("/t/execute", json=body, headers=headers)
        assert second.status_code == 200
        assert second.headers.get("X-Idempotency-Cache") == "hit"
        assert first.json() == second.json()


@pytest.mark.asyncio
async def test_rate_limit(monkeypatch):
    # Configure very low rate limit for testing
    monkeypatch.setenv("T_TOKEN", "secret")
    monkeypatch.setenv("T_RATE_LIMIT", "2")
    monkeypatch.setenv("T_RATE_WINDOW", "1")
    app = create_app()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        headers = {"X-Auth-Token": "secret"}
        body = {"order": {"steps": [{"cmd": "echo", "text": "test"}]}, "dry_run": False}
        # Two requests should be allowed
        r1 = await client.post("/t/execute", json=body, headers=headers)
        r2 = await client.post("/t/execute", json=body, headers=headers)
        assert r1.status_code == 200
        assert r2.status_code == 200
        # Third request within same window should be rate limited
        r3 = await client.post("/t/execute", json=body, headers=headers)
        assert r3.status_code == 429
        assert not r3.json()["ok"]