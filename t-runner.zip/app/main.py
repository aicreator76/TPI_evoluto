from fastapi import FastAPI, Request
import json, os, time, datetime, urllib.request, urllib.error

app = FastAPI()
ALLOWED = {"http_post","echo","sleep","write_log"}

def _http_post(s):
    data = json.dumps(s.get("body", {})).encode("utf-8")
    req = urllib.request.Request(s["url"], data=data, headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return {"code": r.status, "out": r.read(4096).decode("utf-8","replace")}

def _echo(s):  return {"echo": s.get("text","")}
def _sleep(s): sec=float(s.get("seconds",1)); time.sleep(sec); return {"slept": sec}
def _write_log(s):
    base="/tmp/camelot_logs"; os.makedirs(base, exist_ok=True)
    fn=os.path.join(base, datetime.date.today().strftime("%Y-%m-%d")+".log")
    open(fn,"a",encoding="utf-8").write(json.dumps(s.get("data",{}),ensure_ascii=False)+"\n")
    return {"file":fn}

DISPATCH={"http_post":_http_post,"echo":_echo,"sleep":_sleep,"write_log":_write_log}

@app.post("/t/execute")
async def exec_t(req: Request):
    body = await req.json()
    order = body.get("order", body); dry = bool(body.get("dry_run", False))
    res=[]
    for i, s in enumerate(order.get("steps",[]),1):
        cmd=s.get("cmd")
        if cmd not in ALLOWED: res.append({"i":i,"cmd":cmd,"ok":False,"error":"Command not allowed"}); continue
        if dry and cmd!="echo": res.append({"i":i,"cmd":cmd,"ok":True,"dry_run":True}); continue
        try: res.append({"i":i,"cmd":cmd,"ok":True,"result":DISPATCH[cmd](s)})
        except urllib.error.HTTPError as e: res.append({"i":i,"cmd":cmd,"ok":False,"error":f"HTTP {e.code}: {e.reason}"})
        except Exception as e: res.append({"i":i,"cmd":cmd,"ok":False,"error":str(e)})
    return {"ok": all(r.get("ok") for r in res) if res else True, "dry_run": dry, "results": res}