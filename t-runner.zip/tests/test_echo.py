from app.main import ALLOWED

def test_allowlist():
    assert "echo" in ALLOWED