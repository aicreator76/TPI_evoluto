# Camelot T-Runner

This repository provides a minimal **T‑Runner** service implemented with FastAPI and containerized with Docker.  It exposes a single endpoint to execute a sequence of commands from a trusted allowlist.  The default allowlist includes `echo`, `http_post`, `sleep` and `write_log`.

## Quick start

Build and run the service using docker compose:

```bash
docker compose up -d
```

Send a simple echo request:

```bash
curl -s http://127.0.0.1:8080/t/execute \
  -H 'content-type: application/json' \
  -d '{"order":{"steps":[{"cmd":"echo","text":"ping"}]},"dry_run":false}'
```

The response should include the echoed text `ping`.

## Tests

This repository includes a minimal `pytest` suite (`tests/test_echo.py`) that verifies the allowlist contains the `echo` command.  To run tests locally install dependencies from `requirements.txt` and then run `pytest`:

```bash
python3 -m pip install -r requirements.txt
pip install pytest
pytest -q
```

## CI

GitHub Actions workflow in `.github/workflows/ci.yml` automatically installs dependencies and runs the test suite on every push to `main`.