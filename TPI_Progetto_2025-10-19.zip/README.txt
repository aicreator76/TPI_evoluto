﻿TPI — pacchetto portabile
=========================
1) Estrarre lo ZIP in una cartella qualsiasi.
2) Doppio clic su 'START TPI.cmd' (apre la dashboard offline).
   In alternativa: usare i link '.url' per aprire direttamente con un ruolo (RSPP/Datore/Revisore).
Note: funziona su qualsiasi PC senza installare nulla. Le lingue si cambiano dai chip IT/EN/DE/FR.
